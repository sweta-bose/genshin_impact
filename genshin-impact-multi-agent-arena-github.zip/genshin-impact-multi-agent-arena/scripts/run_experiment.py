"""Run stochastic strategic-agent experiments."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from genshin_agent.data_loader import load_dataset
from genshin_agent.features import add_features
from genshin_agent.simulation import run_experiment, summarize, run_ablation
from genshin_agent.visualization import plot_experiment_summary
from genshin_agent.agent import ContextAwareAgent
from genshin_agent.arena import ArenaGenerator
from genshin_agent.config import AgentConfig

DATA = ROOT / "data" / "genshin_impact.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = add_features(load_dataset(DATA))

results = run_experiment(df, n_episodes=50, seed=42)
summary = summarize(results)

results.to_csv(OUT / "experiment_results.csv", index=False)
summary.to_csv(OUT / "baseline_comparison.csv", index=False)
plot_experiment_summary(summary, OUT / "strategy_comparison.png")

ablation = run_ablation(df, n_episodes=30, seed=42)
ablation.to_csv(OUT / "ablation_results.csv", index=False)

# One explainable example episode.
agent = ContextAwareAgent(df, AgentConfig(random_seed=42))
arena = ArenaGenerator(seed=42).generate()
team = agent.choose_team(arena)
lines = [
    "EXAMPLE CONTEXT-AWARE DECISION",
    f"Arena: {arena.as_dict()}",
    "Selected team: " + ", ".join(c["name"] for c in team),
    "Elements: " + ", ".join(c["element"] for c in team),
    "Roles: " + " | ".join(f"{c['name']}: {c['roles']}" for c in team),
]
(OUT / "example_decision.txt").write_text("\n".join(lines), encoding="utf-8")

summary_text = summary.to_string(index=False)
(OUT / "experiment_summary.txt").write_text(
    "All scores are model-generated contextual simulation scores, not official match outcomes.\n\n"
    + summary_text
    + "\n\nAblation mean scores:\n"
    + ablation.groupby("mode")["score"].mean().sort_values(ascending=False).to_string(),
    encoding="utf-8"
)

print(summary_text)
print("\nOutputs written to:", OUT)
