"""Simple baselines for comparison."""

class StatOnlyBaseline:
    def __init__(self, df, team_size=4):
        self.df = df
        self.team_size = team_size

    def select(self, arena):
        return self.df.nlargest(
            self.team_size, "combat_strength"
        ).to_dict("records")

class PopularityBaseline:
    def __init__(self, df, team_size=4):
        self.df = df
        self.team_size = team_size

    def select(self, arena):
        return self.df.nlargest(
            self.team_size, "popularity_signal"
        ).to_dict("records")

class BalancedBaseline:
    """Simple role-aware baseline without uncertainty-aware planning."""
    def __init__(self, df, team_size=4):
        self.df = df
        self.team_size = team_size

    def select(self, arena):
        pool = self.df.sort_values("combat_strength", ascending=False).to_dict("records")
        selected = []
        needed = ["DPS", "Support", "Survivability"]
        for role in needed:
            for c in pool:
                if role in c["roles_list"] and c["name"] not in {x["name"] for x in selected}:
                    selected.append(c)
                    break
        for c in pool:
            if len(selected) >= self.team_size:
                break
            if c["name"] not in {x["name"] for x in selected}:
                selected.append(c)
        return selected[:self.team_size]
