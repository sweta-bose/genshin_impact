"""Configuration constants for the research prototype."""

from dataclasses import dataclass

SCORE_WEIGHTS = {
    "survival": 0.25,
    "objective": 0.20,
    "resource": 0.15,
    "synergy": 0.15,
    "damage": 0.10,
    "adaptability": 0.10,
    "risk_efficiency": 0.05,
}

WEATHER_EFFECTS = {
    "Thunderstorm": {"element_bonus": {"Electro": 0.30}, "visibility": -0.15},
    "Sandstorm": {"weapon_penalty": {"Bow": -0.20, "Catalyst": -0.10}, "Claymore": 0.10},
    "Blizzard": {"element_bonus": {"Cryo": 0.25}, "movement_penalty": -0.20},
    "Monsoon": {"element_bonus": {"Hydro": 0.20}, "reaction_bonus": 0.20},
    "Solar Flare": {"element_bonus": {"Pyro": 0.25}, "element_penalty": {"Cryo": -0.20}},
    "Clear": {},
}

TERRAIN_EFFECTS = {
    "Floating Islands": {"weapon_bonus": {"Bow": 0.18, "Catalyst": 0.12},
                         "role_penalty": {"On-Field": -0.05}},
    "Crystalline Caverns": {"element_bonus": {"Geo": 0.25},
                            "survivability_bonus": 0.15},
    "Dense Forest": {"element_bonus": {"Dendro": 0.20},
                     "reaction_bonus": 0.15},
    "Ancient Ruins": {"resource_penalty": 0.15},
    "Open Ground": {},
}

OBJECTIVE_PROFILES = {
    "Eliminate": {"damage": 1.0, "survival": 0.7, "objective": 0.7},
    "Control": {"damage": 0.6, "survival": 0.9, "objective": 1.0},
    "Protect": {"damage": 0.5, "survival": 1.0, "objective": 1.0},
    "Collect": {"damage": 0.4, "survival": 0.8, "objective": 1.0},
    "Survive": {"damage": 0.2, "survival": 1.0, "objective": 1.0},
    "Escort": {"damage": 0.5, "survival": 1.0, "objective": 1.0},
}

EVENTS = [
    "Lava eruption",
    "Flood",
    "Corruption zone",
    "Gravity inversion",
    "Element suppression",
    "Energy blackout",
    "Shield nullification",
    "Time distortion",
    "No event",
]

ELEMENT_REACTIONS = {
    frozenset(("Pyro", "Hydro")),
    frozenset(("Pyro", "Cryo")),
    frozenset(("Pyro", "Electro")),
    frozenset(("Pyro", "Dendro")),
    frozenset(("Hydro", "Electro")),
    frozenset(("Hydro", "Cryo")),
    frozenset(("Hydro", "Dendro")),
    frozenset(("Cryo", "Electro")),
    frozenset(("Cryo", "Dendro")),
    frozenset(("Dendro", "Electro")),
    frozenset(("Anemo", "Pyro")),
    frozenset(("Anemo", "Hydro")),
    frozenset(("Anemo", "Cryo")),
    frozenset(("Anemo", "Electro")),
    frozenset(("Anemo", "Dendro")),
    frozenset(("Geo", "Pyro")),
    frozenset(("Geo", "Hydro")),
    frozenset(("Geo", "Cryo")),
    frozenset(("Geo", "Electro")),
}

@dataclass
class AgentConfig:
    team_size: int = 4
    beam_width: int = 6
    candidate_pool: int = 12
    event_samples: int = 6
    random_seed: int = 42
