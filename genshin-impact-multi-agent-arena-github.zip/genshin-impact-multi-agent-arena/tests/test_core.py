import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from genshin_agent.data_loader import load_dataset, validate_dataset
from genshin_agent.features import add_features
from genshin_agent.arena import ArenaGenerator
from genshin_agent.evaluator import TeamEvaluator
from genshin_agent.agent import ContextAwareAgent

DATA = ROOT / "data" / "genshin_impact.csv"

def test_dataset_loads():
    df = load_dataset(DATA)
    checks = validate_dataset(df)
    assert checks["rows"] == 103
    assert checks["unique_characters"] == 103
    assert checks["duplicate_rows"] == 0

def test_features_are_bounded():
    df = add_features(load_dataset(DATA))
    for col in ["combat_strength", "role_value", "popularity_signal", "survivability_proxy"]:
        assert df[col].between(0, 1).all()

def test_team_score_is_bounded():
    df = add_features(load_dataset(DATA))
    agent = ContextAwareAgent(df)
    arena = ArenaGenerator(42).generate()
    team = agent.choose_team(arena)
    score = TeamEvaluator(df).total_score(team, arena)
    assert len(team) == 4
    assert 0 <= score <= 1

def test_agent_is_reproducible_for_team_selection():
    df = add_features(load_dataset(DATA))
    a1 = ContextAwareAgent(df)
    a2 = ContextAwareAgent(df)
    arena = ArenaGenerator(42).generate()
    t1 = [c["name"] for c in a1.choose_team(arena)]
    t2 = [c["name"] for c in a2.choose_team(arena)]
    assert t1 == t2
