"""Beam-search team selection."""

from .config import AgentConfig
from .synergy import team_synergy

class TeamSelector:
    def __init__(self, df, evaluator, config=None):
        self.df = df
        self.evaluator = evaluator
        self.config = config or AgentConfig()

    def _candidate_pool(self):
        ranked = self.df.sort_values(
            ["combat_strength", "survivability_proxy"],
            ascending=False
        )
        return ranked.head(self.config.candidate_pool).to_dict("records")

    def _partial_score(self, team, arena):
        if not team:
            return 0.0
        return self.evaluator.total_score(team, arena)

    def select(self, arena):
        candidates = self._candidate_pool()
        beams = [tuple()]

        for _ in range(self.config.team_size):
            expanded = []
            for team in beams:
                used = {c["name"] for c in team}
                for c in candidates:
                    if c["name"] in used:
                        continue
                    new_team = team + (c,)
                    score = self._partial_score(new_team, arena)
                    expanded.append((score, new_team))

            expanded.sort(key=lambda x: x[0], reverse=True)

            # Keep diversity by preferring distinct element sets when possible.
            selected = []
            seen_signatures = set()
            for score, team in expanded:
                signature = tuple(sorted(c["element"] for c in team))
                if signature not in seen_signatures or len(selected) < self.config.beam_width // 2:
                    selected.append((score, team))
                    seen_signatures.add(signature)
                if len(selected) >= self.config.beam_width:
                    break
            beams = [team for _, team in selected]

        best = max(beams, key=lambda t: self.evaluator.total_score(t, arena))
        return list(best)
