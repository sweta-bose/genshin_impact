"""Context-aware strategic agent."""

import random
from .config import AgentConfig
from .arena import ArenaGenerator, ArenaState
from .evaluator import TeamEvaluator
from .team_selector import TeamSelector

ACTIONS = [
    "Attack", "Skill", "Burst", "Swap", "Defend",
    "Gather Resource", "Capture Objective", "Retreat", "Coordinate"
]

class ContextAwareAgent:
    def __init__(self, df, config=None):
        self.config = config or AgentConfig()
        self.rng = random.Random(self.config.random_seed)
        self.evaluator = TeamEvaluator(df)
        self.selector = TeamSelector(df, self.evaluator, self.config)

    def choose_team(self, arena):
        return self.selector.select(arena)

    def choose_action(self, team, arena):
        # Explainable action policy based on objective/context rather than raw DPS.
        if arena.objective == "Survive":
            if arena.event in {"Energy blackout", "Lava eruption", "Corruption zone"}:
                return "Defend"
            return "Retreat" if arena.turn % 5 == 4 else "Coordinate"

        if arena.objective in {"Control", "Protect", "Escort"}:
            if arena.event == "Gravity inversion":
                return "Reposition"
            return "Capture Objective"

        if arena.objective == "Collect":
            return "Gather Resource"

        # Elimination objective: preserve resources when uncertainty is high.
        if arena.event == "Energy blackout":
            return "Skill"
        if arena.event == "Shield nullification":
            return "Attack"
        return "Coordinate"

    def run_episode(self, arena=None, turns=10):
        arena = arena or ArenaGenerator(self.config.random_seed).generate()
        team = self.choose_team(arena)
        actions = []
        for _ in range(turns):
            event = arena.sample_event(arena)
            action = self.choose_action(team, arena)
            actions.append({"turn": arena.turn, "event": event, "action": action})
        score = self.evaluator.total_score(team, arena)
        return team, actions, score
