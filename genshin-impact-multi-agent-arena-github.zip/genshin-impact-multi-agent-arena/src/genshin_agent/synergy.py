"""Transparent proxy synergy graph.

The supplied CSV does not contain an official synergy matrix, so this module
creates an interpretable proxy using only roles/elements from the dataset and
the elemental-reaction concept stated in the challenge.
"""

from itertools import combinations
import numpy as np
from .config import ELEMENT_REACTIONS

def pair_synergy(a, b):
    score = 0.0
    ra, rb = set(a["roles_list"]), set(b["roles_list"])

    # Elemental interaction.
    if frozenset((a["element"], b["element"])) in ELEMENT_REACTIONS:
        score += 0.35

    # Role complementarity.
    if "DPS" in ra and ("Support" in rb or "Survivability" in rb):
        score += 0.25
    if "DPS" in rb and ("Support" in ra or "Survivability" in ra):
        score += 0.25

    # Double-support / survival redundancy is useful but diminishing.
    if "Survivability" in ra and "Survivability" in rb:
        score += 0.05

    # Distinct functional roles are rewarded.
    if bool(ra & {"DPS"}) != bool(rb & {"DPS"}):
        score += 0.10

    return min(1.0, score)

def team_synergy(team):
    if len(team) < 2:
        return 0.0
    vals = [pair_synergy(a, b) for a, b in combinations(team, 2)]
    return float(np.mean(vals))

def synergy_edges(df, threshold=0.25):
    edges = []
    records = df.to_dict("records")
    for i, a in enumerate(records):
        for b in records[i+1:]:
            s = pair_synergy(a, b)
            if s >= threshold:
                edges.append((a["name"], b["name"], s))
    return edges
