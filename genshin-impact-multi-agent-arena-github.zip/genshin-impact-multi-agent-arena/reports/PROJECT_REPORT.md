# Genshin Impact Multi-Agent Combat Arena
## Context-Aware Strategic Combat Under Extreme Uncertainty

### Executive Summary

The supplied challenge requires an AI system for team-based Genshin Impact combat in procedurally generated arenas. The key design premise is that raw character strength does not guarantee victory. The challenge explicitly introduces environmental changes, hidden objectives, dynamic events, partial observability, team synergy and resource constraints.

The supplied character dataset contains 103 rows and 32 original columns. It provides identity, combat statistics, roles, release metadata, community investment signals and constellation pull counts. It does not provide historical match outcomes or action trajectories.

Therefore, the project uses a **context-aware strategic simulation prototype** rather than a supervised win-prediction model.

The architecture has five layers:

1. **Data layer** — load, validate and engineer character features.
2. **Synergy layer** — create a transparent proxy synergy graph.
3. **Arena layer** — generate weather, terrain, objective and hidden events.
4. **Decision layer** — select teams using beam search and choose context-aware actions.
5. **Evaluation layer** — compare the agent with simple baselines and run ablations.

The central methodological principle is to separate **intrinsic character strength** from **contextual usefulness**.

---

# 1. Problem definition

The supplied problem statement asks for an AI agent that can control teams in 1v1, 2v2, 3v3 and 4v4 settings, with NvN as a future extension.

The environment can contain:
- weather;
- terrain;
- elemental field;
- visibility;
- energy flux;
- hazard map;
- objective type.

The challenge also includes hidden objectives such as:
- elimination;
- control zones;
- protecting relic cores;
- collecting elemental orbs;
- surviving longest;
- escorting a moving objective.

Dynamic events can include:
- lava eruption;
- flood;
- corruption zone;
- gravity inversion;
- element suppression;
- energy blackout;
- shield nullification;
- time distortion.

The problem statement says that future events are not directly revealed. The agent must reason under uncertainty.

---

# 2. Dataset audit

The supplied CSV was inspected before modeling.

## 2.1 Dataset size

- Rows: 103
- Original columns: 32
- Unique characters: 103
- Duplicate rows: 0
- Missing cells: 0

The CSV also contains an `Unnamed: 0` index-like column. It is retained in the raw data but is not used as a predictive feature.

## 2.2 Feature groups

### Character identity
- name
- rarity
- weapon
- element
- region
- 3D-model

### Combat
- lvl_90_HP
- lvl_90_ATK
- lvl_90_DEF
- asc_stat_bonus_category

### Roles
- roles

Multiple roles can occur for a character.

### Meta/release
- release_date
- days_since_release
- banner_versions
- banner_dates
- num_banners
- months_since_release
- is_standard_banner
- is_archon

### Community/investment
- pulled_count
- duplicate_rate
- avg_copies_per_player
- c6_rate
- constellation pull counts

---

# 3. Critical modeling decision: no fabricated win labels

A major issue is that the dataset contains no column such as:

```text
win
match_result
damage_dealt
survival_time
objective_score
action
enemy_team
arena_result
```

Therefore, it would be methodologically incorrect to invent a historical win label and train a classifier as if those outcomes existed.

Instead, this project defines an **abstract combat evaluation function** directly from the scoring system specified in the challenge.

This makes the system:
- reproducible;
- explainable;
- honest about the available evidence.

The resulting scores are **simulated model scores**, not real match outcomes.

---

# 4. Feature engineering

## 4.1 Combat strength

HP, ATK and DEF are normalized to [0,1].

\[
CombatStrength =
0.35HP_n + 0.35ATK_n + 0.30DEF_n
\]

This represents baseline statistical strength only.

It is deliberately not the final team score.

## 4.2 Role value

Roles are parsed from the comma-separated `roles` column.

The model recognizes:
- On-Field
- Off-Field
- DPS
- Support
- Survivability

Role information is used for team construction and contextual scoring.

## 4.3 Popularity signal

The challenge explicitly warns that popularity features are noisy.

A separate popularity signal is calculated from:
- pulled_count;
- num_banners;
- duplicate_rate;
- avg_copies_per_player.

This feature is not treated as combat strength.

That distinction is important because a model that simply learns popularity can fail when the arena penalizes a popular play pattern.

## 4.4 Survivability proxy

A transparent survivability proxy combines:
- HP;
- DEF;
- explicit Survivability role.

This is useful because the competition score assigns 25% to survival.

---

# 5. Synergy model

The problem statement says a synergy graph is generated, but the CSV does not contain an official pairwise synergy table.

Therefore, the repository creates a **proxy synergy graph**.

For a pair of characters:

### Element compatibility
If their elements form a reaction-compatible pair, synergy increases.

### Role complementarity
DPS + Support or DPS + Survivability receives a positive contribution.

### Functional diversity
Teams containing multiple functional roles receive a positive contribution.

### Redundancy
Multiple survivability roles can help resilience, but excessive duplication is not given unlimited benefit.

The pair score is bounded to [0,1].

Team synergy is the mean pairwise synergy over all character pairs.

This is an intentionally interpretable baseline.

---

# 6. Arena model

Each episode samples:

- weather;
- terrain;
- objective.

The environment also has a dynamic event.

Examples:

### Thunderstorm
- Electro receives a bonus.
- visibility is reduced.

### Sandstorm
- Bow and Catalyst receive penalties.
- Claymore receives a small stagger-related benefit.

### Blizzard
- Cryo receives a bonus.
- movement is impaired.

### Monsoon
- Hydro receives a bonus.

### Floating Islands
- Bow/Catalyst receive contextual advantages.
- melee-heavy teams receive less benefit.

### Crystalline Caverns
- Geo and survivability are more valuable.

### Dense Forest
- Dendro and reaction-oriented compositions gain value.

### Ancient Ruins
- resource reliability is reduced.

These are operationalizations of the challenge examples, not claims about the actual Genshin game.

---

# 7. Competition score implementation

The evaluator follows the supplied weights:

| Component | Weight |
|---|---:|
| Survival | 25% |
| Objective Control | 20% |
| Resource Management | 15% |
| Team Synergy | 15% |
| Damage Contribution | 10% |
| Adaptability | 10% |
| Risk Efficiency | 5% |

The weighted sum is the contextual team score.

This directly implements the central design insight:

> A team should not maximize damage alone.

---

# 8. Team-selection algorithm

## Why beam search?

With 103 characters, the number of 4-character combinations is large:

\[
{103 \choose 4}
\]

A complete brute-force evaluation is unnecessary for a baseline prototype.

Beam search works as follows:

1. Start with no characters.
2. Add candidate characters.
3. Evaluate each partial team.
4. Keep only the strongest/diverse candidates.
5. Repeat until four characters are selected.

The search therefore considers multiple plausible team compositions without enumerating the full combinatorial space.

---

# 9. Uncertainty handling

The challenge describes a partially observable planning problem.

The agent cannot know the future event.

The intended formulation is:

\[
EV(T) = \sum_e P(e|history)V(T,e)
\]

The current prototype uses a stochastic event generator and evaluates robustness across event types.

A future research version should learn:

\[
P(e_{t+1}|history, arena, opponent, objective)
\]

from actual match logs.

---

# 10. Action policy

The action space follows the supplied challenge:

- Move
- Attack
- Skill
- Burst
- Swap
- Defend
- Gather Resource
- Capture Objective
- Retreat
- Coordinate

The current prototype uses an explainable contextual policy.

Examples:

### Survival objective + dangerous event
Prefer **Defend**.

### Control/Protect/Escort
Prefer **Capture Objective** or **Coordinate**.

### Collect
Prefer **Gather Resource**.

### Energy blackout
Avoid blindly depending on burst-heavy behavior.

This is a strategic baseline rather than a learned policy.

---

# 11. Baselines

Three baselines are included.

## Stat-only

Selects the four characters with the highest normalized combat strength.

This represents:

> "Pick the strongest characters."

## Popularity-only

Selects the four characters with the highest community popularity signal.

This tests the failure mode described by the challenge.

## Balanced

Selects characters to cover:
- DPS;
- Support;
- Survivability;

then fills remaining slots using combat strength.

This tests whether simple role balance alone can capture the value of the full contextual agent.

---

# 12. Experiments

The experiment script generates repeated random arenas.

For each episode it evaluates:
- ContextAware
- StatOnly
- PopularityOnly
- Balanced

The output is:

```text
outputs/experiment_results.csv
outputs/baseline_comparison.csv
outputs/strategy_comparison.png
```

The comparison should be interpreted as:

> Which policy receives a higher score under the simulator's explicit scoring function?

It should **not** be interpreted as a claim about real-world Genshin win rate.

---

# 13. Ablation study

The repository also runs:

- Full context
- No synergy
- No objective information
- Stat-only

Ablation is important because it tests whether contextual components actually affect the decisions.

The desired research interpretation is not simply "the proposed model wins".

Instead, ask:

> How much does performance change when a strategic information source is removed?

---

# 14. Expected findings

The project is designed to test the following hypotheses.

### H1: Context matters

The same character should receive different contextual value under different arenas.

### H2: Raw stats are insufficient

A high combat-strength team can lose contextual value when:
- the objective rewards survival;
- energy is unavailable;
- shields are especially valuable;
- a terrain penalizes its weapons;
- an elemental condition suppresses its key element.

### H3: Popularity is not equivalent to strategic value

Community investment signals can identify frequently used characters without proving that those characters are optimal in every arena.

### H4: Role diversity improves robustness

Teams containing DPS + Support + Survivability should be less fragile than teams composed around a single role.

### H5: Synergy improves contextual performance

Removing the synergy component should change the selected compositions and can reduce simulated contextual score.

These are hypotheses to test with the generated outputs, not conclusions that should be claimed without running the experiment.

---

# 15. Limitations

This is the most important section for academic credibility.

## 15.1 No real battle outcomes

There is no observed target variable.

Therefore the model cannot be validated as a real win predictor.

## 15.2 No skill-kit data

The dataset does not specify:
- skill multipliers;
- burst costs;
- cooldowns;
- healing values;
- shields;
- reaction multipliers;
- elemental application frequency.

Therefore the combat simulator is abstract.

## 15.3 Proxy synergy

The synergy graph is inferred from roles and elements rather than obtained from actual gameplay telemetry.

## 15.4 Simplified events

Arena effects are based on the challenge description's examples.

## 15.5 Small dataset

Only 103 character rows are available.

## 15.6 No opponent model

The current baseline does not learn an adversarial opponent policy.

---

# 16. Future research roadmap

The strongest next version should collect actual match trajectories.

Each timestep should record:

```text
match_id
turn
team_id
character_id
arena_state
objective
enemy_state
hp
energy
cooldown
position
available_actions
chosen_action
damage
reaction
objective_progress
survival
match_result
```

Then the project can move from a hand-designed simulator to:

### Phase 1
Supervised outcome modeling.

### Phase 2
Opponent behavior modeling.

### Phase 3
Contextual bandits.

### Phase 4
Monte Carlo Tree Search.

### Phase 5
Multi-agent reinforcement learning.

### Phase 6
Self-play against learned opponents.

The final target would be a partially observable multi-agent decision process.

---

# 17. Final conclusion

The central lesson of the challenge is that **character strength and strategic value are not the same quantity**.

A robust agent therefore needs to answer:

1. What is the objective?
2. What is the arena environment?
3. Which characters complement one another?
4. Which resources are available?
5. Which future events are plausible?
6. How fragile is the proposed strategy?
7. Should the team attack, defend, capture, gather, coordinate or retreat?

The repository operationalizes these questions in an explainable baseline that can later be upgraded with real battle logs and reinforcement learning.

