"""Experimental evaluation and ablation utilities."""

import numpy as np
import pandas as pd
from .arena import ArenaGenerator
from .agent import ContextAwareAgent
from .baselines import StatOnlyBaseline, PopularityBaseline, BalancedBaseline
from .evaluator import TeamEvaluator
from .config import AgentConfig

def run_experiment(df, n_episodes=200, seed=42):
    df = df.copy()
    agent = ContextAwareAgent(df, AgentConfig(random_seed=seed))
    evaluator = TeamEvaluator(df)
    baselines = {
        "ContextAware": agent,
        "StatOnly": StatOnlyBaseline(df),
        "PopularityOnly": PopularityBaseline(df),
        "Balanced": BalancedBaseline(df),
    }

    rows = []
    for i in range(n_episodes):
        generator = ArenaGenerator(seed=seed + i)
        arena = generator.generate()
        # Hidden event is sampled before evaluation so event-specific
        # robustness actually affects the episode score.
        generator.sample_event(arena)
        for name, policy in baselines.items():
            if name == "ContextAware":
                team = policy.choose_team(arena)
            else:
                team = policy.select(arena)
            score = evaluator.total_score(team, arena)
            rows.append({
                "episode": i,
                "policy": name,
                "score": score,
                "weather": arena.weather,
                "terrain": arena.terrain,
                "objective": arena.objective,
                "event": arena.event,
            })
    return pd.DataFrame(rows)

def summarize(results):
    return (
        results.groupby("policy")["score"]
        .agg(["mean", "std", "min", "max"])
        .sort_values("mean", ascending=False)
        .reset_index()
    )

def run_ablation(df, n_episodes=100, seed=42):
    """Compare contextual agent with progressively simplified scoring."""
    from .team_selector import TeamSelector

    rows = []
    base_agent = ContextAwareAgent(df, AgentConfig(random_seed=seed))
    generator = ArenaGenerator(seed=seed)

    for mode in ["full_context", "no_synergy", "no_objective", "stat_only"]:
        for i in range(n_episodes):
            arena = generator.generate()
            generator.sample_event(arena)
            if mode == "full_context":
                team = base_agent.choose_team(arena)
                evaluator = TeamEvaluator(df)
            else:
                evaluator = TeamEvaluator(df)

                class ModifiedSelector(TeamSelector):
                    def _partial_score(self, team, arena):
                        if mode == "stat_only":
                            if not team:
                                return 0
                            return float(np.mean([c["combat_strength"] for c in team]))
                        parts = evaluator.score_components(team, arena)
                        if mode == "no_synergy":
                            parts["synergy"] = 0.0
                        if mode == "no_objective":
                            parts["objective"] = 0.0
                        return sum(
                            evaluator_weight * parts[key]
                            for key, evaluator_weight in {
                                "survival": .25, "objective": .20,
                                "resource": .15, "synergy": .15,
                                "damage": .10, "adaptability": .10,
                                "risk_efficiency": .05
                            }.items()
                        )

                selector = ModifiedSelector(df, evaluator, AgentConfig(random_seed=seed))
                team = selector.select(arena)

            score = evaluator.total_score(team, arena)
            rows.append({"mode": mode, "episode": i, "score": score})
    return pd.DataFrame(rows)
