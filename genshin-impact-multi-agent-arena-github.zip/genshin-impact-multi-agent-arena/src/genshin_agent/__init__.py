"""Context-aware strategic Genshin combat research prototype."""
