"""Context-aware team evaluation."""

import numpy as np
from .config import (
    SCORE_WEIGHTS, WEATHER_EFFECTS, TERRAIN_EFFECTS,
    OBJECTIVE_PROFILES
)
from .synergy import team_synergy

class TeamEvaluator:
    def __init__(self, df):
        self.df = df

    def _element_context(self, team, arena):
        score = np.mean([1.0] * len(team))
        weather = WEATHER_EFFECTS[arena.weather]
        terrain = TERRAIN_EFFECTS[arena.terrain]

        bonuses = []
        for c in team:
            x = 1.0
            x += weather.get("element_bonus", {}).get(c["element"], 0.0)
            x += weather.get("element_penalty", {}).get(c["element"], 0.0)
            x += terrain.get("element_bonus", {}).get(c["element"], 0.0)
            x += terrain.get("survivability_bonus", 0.0) * (
                1.0 if "Survivability" in c["roles_list"] else 0.0
            )
            x += terrain.get("weapon_bonus", {}).get(c["weapon"], 0.0)
            x += terrain.get("weapon_penalty", {}).get(c["weapon"], 0.0)
            bonuses.append(max(0.0, x))
        return float(np.mean(bonuses))

    def _role_coverage(self, team):
        roles = set(r for c in team for r in c["roles_list"])
        coverage = 0.0
        coverage += 0.35 if "DPS" in roles else 0.0
        coverage += 0.25 if "Support" in roles else 0.0
        coverage += 0.25 if "Survivability" in roles else 0.0
        coverage += 0.15 if ("On-Field" in roles or "Off-Field" in roles) else 0.0
        return min(1.0, coverage)

    def _event_robustness(self, team, event):
        elements = {c["element"] for c in team}
        roles = set(r for c in team for r in c["roles_list"])
        if event == "Energy blackout":
            return 0.85 if "Support" in roles and "Survivability" in roles else 0.55
        if event == "Element suppression":
            return min(1.0, 0.55 + 0.10 * len(elements))
        if event == "Shield nullification":
            return 0.65 if "DPS" in roles else 0.75
        if event == "Flood":
            return 0.85 if "Hydro" not in elements else 0.75
        if event == "Gravity inversion":
            return 0.80 if "Bow" in [c["weapon"] for c in team] else 0.60
        if event == "Lava eruption":
            return 0.75 if "Survivability" in roles else 0.55
        if event == "Corruption zone":
            return 0.80 if "Survivability" in roles else 0.60
        if event == "Time distortion":
            return 0.75 if "Off-Field" in roles else 0.65
        return 0.70

    def score_components(self, team, arena):
        if not team:
            return {k: 0.0 for k in SCORE_WEIGHTS}

        avg_strength = float(np.mean([c["combat_strength"] for c in team]))
        synergy = team_synergy(team)
        role = self._role_coverage(team)
        context = self._element_context(team, arena)
        objective_profile = OBJECTIVE_PROFILES[arena.objective]

        survival = np.clip(
            0.55 * np.mean([c["survivability_proxy"] for c in team])
            + 0.20 * role
            + 0.15 * (1.0 if objective_profile["survival"] >= 0.9 else 0.7)
            + 0.10 * (context - 0.5),
            0, 1
        )

        objective = np.clip(
            0.45 * role
            + 0.25 * objective_profile["objective"]
            + 0.20 * context
            + 0.10 * synergy,
            0, 1
        )

        resource = np.clip(
            0.55
            + 0.20 * (1.0 if "Off-Field" in set(r for c in team for r in c["roles_list"]) else 0.0)
            + 0.15 * (1.0 if arena.terrain != "Ancient Ruins" else 0.0)
            + 0.10 * role,
            0, 1
        )

        damage = np.clip(
            0.70 * avg_strength
            + 0.20 * synergy
            + 0.10 * context,
            0, 1
        )

        adaptability = np.clip(
            0.40 * len(set(c["element"] for c in team)) / 4.0
            + 0.25 * role
            + 0.20 * synergy
            + 0.15 * self._event_robustness(team, arena.event),
            0, 1
        )

        risk_efficiency = np.clip(
            0.40 * survival
            + 0.30 * objective
            + 0.20 * adaptability
            + 0.10 * resource,
            0, 1
        )

        # Event-specific shock.
        event_robustness = self._event_robustness(team, arena.event)
        survival = np.clip(survival * (0.75 + 0.25 * event_robustness), 0, 1)
        damage = np.clip(damage * (0.70 + 0.30 * context), 0, 1)

        return {
            "survival": float(survival),
            "objective": float(objective),
            "resource": float(resource),
            "synergy": float(synergy),
            "damage": float(damage),
            "adaptability": float(adaptability),
            "risk_efficiency": float(risk_efficiency),
        }

    def total_score(self, team, arena):
        parts = self.score_components(team, arena)
        return float(sum(SCORE_WEIGHTS[k] * parts[k] for k in SCORE_WEIGHTS))
