# System Architecture

```text
                    +----------------------+
                    |  Genshin CSV        |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Data validation      |
                    | + feature engineering|
                    +----------+-----------+
                               |
             +-----------------+-----------------+
             |                                   |
             v                                   v
    +-------------------+              +-------------------+
    | Character value   |              | Proxy synergy     |
    | HP/ATK/DEF/roles  |              | elements + roles  |
    +---------+---------+              +---------+---------+
              |                                  |
              +----------------+-----------------+
                               |
                               v
                    +----------------------+
                    | Arena generator      |
                    | weather/terrain/     |
                    | objective/event      |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Contextual evaluator |
                    | 7 weighted criteria  |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Beam-search selector |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Context-aware agent  |
                    | action policy       |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Simulation +         |
                    | baseline comparison  |
                    +----------------------+
