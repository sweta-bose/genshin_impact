"""Publication-friendly plots."""

from pathlib import Path
import matplotlib.pyplot as plt

def plot_experiment_summary(summary, path):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(summary["policy"], summary["mean"], yerr=summary["std"], capsize=4)
    ax.set_ylabel("Mean simulated contextual score")
    ax.set_xlabel("Policy")
    ax.set_title("Context-aware agent vs. baselines")
    ax.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)

def plot_element_distribution(df, path):
    counts = df["element"].value_counts()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(counts.index, counts.values)
    ax.set_title("Character distribution by element")
    ax.set_ylabel("Number of characters")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)

def plot_stat_distributions(df, path):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.boxplot(
        [df["lvl_90_HP"], df["lvl_90_ATK"], df["lvl_90_DEF"]],
        labels=["HP", "ATK", "DEF"]
    )
    ax.set_title("Level-90 combat-stat distributions")
    ax.set_ylabel("Raw value")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)

def plot_popularity_vs_attack(df, path):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(df["lvl_90_ATK"], df["pulled_count"], alpha=0.75)
    ax.set_xlabel("Level-90 ATK")
    ax.set_ylabel("Pulled count")
    ax.set_title("Popularity is not a direct proxy for ATK")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)
