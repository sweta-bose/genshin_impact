"""Procedural arena and uncertainty model."""

from dataclasses import dataclass, field
import random
from .config import WEATHER_EFFECTS, TERRAIN_EFFECTS, OBJECTIVE_PROFILES, EVENTS

@dataclass
class ArenaState:
    weather: str
    terrain: str
    objective: str
    history: list = field(default_factory=list)
    event: str = "No event"
    turn: int = 0

    def as_dict(self):
        return {
            "weather": self.weather,
            "terrain": self.terrain,
            "objective": self.objective,
            "event": self.event,
            "turn": self.turn,
        }

class ArenaGenerator:
    def __init__(self, seed=42):
        self.rng = random.Random(seed)
        self.weathers = list(WEATHER_EFFECTS.keys())
        self.terrains = list(TERRAIN_EFFECTS.keys())
        self.objectives = list(OBJECTIVE_PROFILES.keys())

    def generate(self):
        return ArenaState(
            weather=self.rng.choice(self.weathers),
            terrain=self.rng.choice(self.terrains),
            objective=self.rng.choice(self.objectives),
        )

    def sample_event(self, state):
        # Uniform baseline prior; history can be used to update this later.
        event = self.rng.choice(EVENTS)
        state.history.append(event)
        state.event = event
        state.turn += 1
        return event
