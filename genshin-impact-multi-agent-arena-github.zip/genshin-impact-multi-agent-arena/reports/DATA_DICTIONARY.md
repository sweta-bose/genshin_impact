# Data Dictionary

| Column | Meaning used in this project |
|---|---|
| name | Character name |
| rarity | Dataset rarity value |
| weapon | Weapon category |
| element | Element |
| region | Region |
| release_date | Release date |
| days_since_release | Days since release |
| roles | Comma-separated role labels |
| lvl_90_HP | Level-90 HP |
| lvl_90_ATK | Level-90 ATK |
| lvl_90_DEF | Level-90 DEF |
| asc_stat_bonus_category | Ascension bonus category |
| duplicate_rate | Duplicate ownership/investment signal |
| c6_rate | C6 investment signal |
| avg_copies_per_player | Average copies per player |
| num_banners | Number of banners |
| months_since_release | Months since release |
| is_standard_banner | Standard-banner indicator |
| is_archon | Archon indicator |
| pulled_count | Community pull count |
| constellation_0_pull ... constellation_7_pull | Community constellation pull counts |
| banner_versions | Banner version history |
| banner_dates | Banner date history |
| 3D-model | Model descriptor |
