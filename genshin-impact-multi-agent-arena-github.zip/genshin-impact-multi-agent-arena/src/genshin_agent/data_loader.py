"""Dataset loading and validation."""

from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = [
    "name", "rarity", "weapon", "element", "region", "release_date",
    "days_since_release", "roles", "constellation_0_pull",
    "constellation_1_pull", "constellation_2_pull", "constellation_3_pull",
    "constellation_4_pull", "constellation_5_pull", "constellation_6_pull",
    "constellation_7_pull", "asc_stat_bonus_category", "lvl_90_HP",
    "lvl_90_ATK", "lvl_90_DEF", "duplicate_rate", "c6_rate",
    "avg_copies_per_player", "num_banners", "months_since_release",
    "is_standard_banner", "is_archon", "pulled_count",
]

def load_dataset(path):
    path = Path(path)
    df = pd.read_csv(path)
    missing = sorted(set(REQUIRED_COLUMNS) - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    df = df.copy()
    df["release_date"] = pd.to_datetime(df["release_date"], errors="coerce")
    df["roles_list"] = df["roles"].fillna("").map(
        lambda x: [r.strip() for r in str(x).split(",") if r.strip()]
    )
    df["role_count"] = df["roles_list"].map(len)
    return df

def validate_dataset(df):
    # roles_list is a Python-list column and cannot be hashed by
    # DataFrame.duplicated(). Validate duplicates on the original tabular
    # columns instead.
    duplicate_columns = [c for c in REQUIRED_COLUMNS if c in df.columns]
    checks = {
        "rows": len(df),
        "columns": len(df.columns),
        "duplicate_rows": int(df[duplicate_columns].duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "unique_characters": int(df["name"].nunique()),
    }
    if checks["duplicate_rows"] != 0:
        raise ValueError("Duplicate rows found.")
    return checks
