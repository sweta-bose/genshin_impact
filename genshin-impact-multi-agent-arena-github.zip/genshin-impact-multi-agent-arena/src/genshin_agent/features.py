"""Feature engineering for contextual character evaluation."""

import numpy as np
import pandas as pd

COMBAT_STATS = ["lvl_90_HP", "lvl_90_ATK", "lvl_90_DEF"]

def minmax(series):
    s = series.astype(float)
    lo, hi = s.min(), s.max()
    if hi == lo:
        return pd.Series(np.ones(len(s)), index=s.index)
    return (s - lo) / (hi - lo)

def add_features(df):
    out = df.copy()

    for c in COMBAT_STATS + [
        "duplicate_rate", "c6_rate", "avg_copies_per_player",
        "num_banners", "months_since_release", "pulled_count"
    ]:
        out[f"{c}_norm"] = minmax(out[c])

    # Base combat score intentionally excludes popularity.
    out["combat_strength"] = (
        0.35 * out["lvl_90_HP_norm"]
        + 0.35 * out["lvl_90_ATK_norm"]
        + 0.30 * out["lvl_90_DEF_norm"]
    )

    role_weights = {
        "On-Field": 1.00,
        "Off-Field": 0.85,
        "DPS": 1.00,
        "Support": 0.90,
        "Survivability": 1.00,
    }

    def role_score(roles):
        if not roles:
            return 0.0
        vals = [role_weights.get(r, 0.5) for r in roles]
        return min(1.0, float(np.mean(vals)))

    out["role_value"] = out["roles_list"].map(role_score)

    # Popularity is retained as a separate noisy signal.
    out["popularity_signal"] = (
        0.55 * out["pulled_count_norm"]
        + 0.20 * out["num_banners_norm"]
        + 0.15 * out["duplicate_rate_norm"]
        + 0.10 * out["avg_copies_per_player_norm"]
    )

    # Robustness proxy: higher survival stats + survivability role.
    out["survivability_proxy"] = (
        0.45 * out["lvl_90_HP_norm"]
        + 0.35 * out["lvl_90_DEF_norm"]
        + 0.20 * out["roles_list"].map(
            lambda rs: 1.0 if "Survivability" in rs else 0.0
        )
    )

    return out
