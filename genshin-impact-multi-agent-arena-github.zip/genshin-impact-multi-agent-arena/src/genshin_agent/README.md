Source package for the context-aware Genshin combat research prototype.
