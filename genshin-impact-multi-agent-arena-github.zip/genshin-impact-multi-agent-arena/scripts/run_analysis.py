"""Run dataset EDA and create research outputs."""

from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from genshin_agent.data_loader import load_dataset, validate_dataset
from genshin_agent.features import add_features
from genshin_agent.visualization import (
    plot_element_distribution, plot_stat_distributions,
    plot_popularity_vs_attack
)

DATA = ROOT / "data" / "genshin_impact.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = load_dataset(DATA)
checks = validate_dataset(df)
features = add_features(df)

summary = pd.DataFrame({
    "metric": list(checks.keys()),
    "value": list(checks.values())
})
summary.to_csv(OUT / "eda_summary.csv", index=False)

features[
    ["name", "element", "roles", "rarity", "combat_strength",
     "survivability_proxy", "popularity_signal"]
].sort_values("combat_strength", ascending=False).to_csv(
    OUT / "character_scores.csv", index=False
)

features.nlargest(20, "combat_strength")[
    ["name", "element", "roles", "combat_strength", "survivability_proxy"]
].to_csv(OUT / "top_context_scores.csv", index=False)

plot_element_distribution(df, OUT / "element_distribution.png")
plot_stat_distributions(df, OUT / "stat_distributions.png")
plot_popularity_vs_attack(df, OUT / "popularity_vs_attack.png")

print("Dataset:", checks)
print("\nTop 10 context-neutral combat strength:")
print(
    features.nlargest(10, "combat_strength")[
        ["name", "element", "roles", "combat_strength"]
    ].to_string(index=False)
)
print("\nEDA outputs written to:", OUT)
