# Genshin Impact Multi-Agent Combat Arena

## Context-Aware Strategic Combat Under Extreme Uncertainty

This repository implements a reproducible research prototype for the supplied **Genshin Impact Multi-Agent Combat Arena** challenge.

The challenge asks for an AI agent that selects teams and actions in dynamic arenas where:
- raw character strength is not sufficient;
- team synergy matters;
- hidden objectives can change the optimal strategy;
- environmental conditions can change character value;
- future events are uncertain;
- survival, objectives, resource management and adaptability matter more than raw damage.

The supplied problem statement defines the final score as:

\[
Score =
0.25 Survival +
0.20 ObjectiveControl +
0.15 ResourceManagement +
0.15 TeamSynergy +
0.10 DamageContribution +
0.10 Adaptability +
0.05 RiskEfficiency
\]

Raw damage therefore contributes only 10% of the score.

> **Important data limitation:** the supplied CSV contains character attributes and community/investment signals, but it contains no historical battle outcomes, action logs, enemy rosters, skill cooldowns, reaction damage tables, or observed arena results. Therefore this project does **not** fabricate a supervised win label. Instead, it builds a context-aware strategic agent and an explicit abstract simulator so the approach can be tested reproducibly. All simulated outcomes are labelled as model-generated, not real Genshin match results.

---

## 1. Project objective

The implementation answers the research question:

> Can an AI learn when a statistically weaker team should deliberately fight, retreat, defend, reposition, or exploit environmental conditions to defeat a stronger opponent under uncertainty?

Because the provided data does not contain real match trajectories, the prototype operationalizes this as:

1. **Character representation**
   - combat statistics
   - role information
   - element/weapon
   - rarity
   - release metadata
   - community investment signals

2. **Context representation**
   - weather
   - terrain
   - objective
   - hidden/dynamic event
   - uncertainty over future events

3. **Team construction**
   - beam-search over candidate teams
   - synergy
   - role coverage
   - environmental fit
   - objective fit
   - survivability
   - risk

4. **Action planning**
   - expected-value evaluation over possible next events
   - context-aware action selection
   - resource conservation
   - retreat/defend/capture choices

5. **Evaluation**
   - comparison against stat-only and popularity-only baselines
   - repeated stochastic arena simulations
   - ablation experiments
   - visualizations

---

## 2. Repository structure

```text
genshin-impact-multi-agent-arena/
├── data/
│   └── genshin_impact.csv
├── src/
│   └── genshin_agent/
│       ├── __init__.py
│       ├── config.py
│       ├── data_loader.py
│       ├── features.py
│       ├── synergy.py
│       ├── arena.py
│       ├── evaluator.py
│       ├── team_selector.py
│       ├── agent.py
│       ├── baselines.py
│       ├── simulation.py
│       └── visualization.py
├── scripts/
│   ├── run_analysis.py
│   └── run_experiment.py
├── reports/
│   └── PROJECT_REPORT.md
├── outputs/
│   └── generated after running the scripts
├── tests/
│   └── test_core.py
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 3. Quick start

### Python version

Python 3.10+ is recommended.

### Install

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Then:

```bash
pip install -r requirements.txt
```

### Run data analysis

```bash
python scripts/run_analysis.py
```

This creates:
- `outputs/eda_summary.csv`
- `outputs/character_scores.csv`
- `outputs/element_distribution.png`
- `outputs/stat_distributions.png`
- `outputs/popularity_vs_attack.png`
- `outputs/top_context_scores.csv`

### Run the strategic simulation

```bash
python scripts/run_experiment.py
```

This creates:
- `outputs/experiment_results.csv`
- `outputs/baseline_comparison.csv`
- `outputs/ablation_results.csv`
- `outputs/experiment_summary.txt`
- `outputs/strategy_comparison.png`

### Run tests

```bash
pytest -q
```

---

## 4. Methodology

### 4.1 Why a contextual agent?

The problem statement explicitly says that:
- a low-stat character can beat a high-stat character;
- support teams can outperform elite DPS teams;
- historical popularity can be misleading;
- environmental shifts can alter the optimal strategy;
- long-term planning can beat short-term damage maximization.

So the model deliberately separates:

**Base strength**
- HP
- ATK
- DEF
- rarity

from:

**Contextual value**
- role coverage
- elemental compatibility
- objective fit
- weather fit
- terrain fit
- expected event robustness
- survivability
- resource preservation

Community popularity is treated as a noisy feature rather than as a direct measure of combat strength.

### 4.2 Team score

For a team \(T\) and arena state \(A\), the evaluator computes:

\[
E(T,A) =
0.25S +
0.20O +
0.15R +
0.15Y +
0.10D +
0.10A_d +
0.05R_e
\]

where:

- \(S\) = survival
- \(O\) = objective control
- \(R\) = resource management
- \(Y\) = team synergy
- \(D\) = damage contribution
- \(A_d\) = adaptability
- \(R_e\) = risk efficiency

This mirrors the supplied competition scoring weights.

### 4.3 Synergy

The CSV does **not** provide an official synergy graph or skill-level reaction matrix. The implementation therefore uses a transparent **proxy synergy graph** derived only from information available in the CSV and the challenge's stated mechanics:

- elemental reaction compatibility;
- role complementarity;
- survivability support;
- DPS/support balance;
- duplicate-role penalties.

This is a research baseline, not an official Genshin combat engine.

### 4.4 Uncertainty

Future events are not known to the agent.

The agent estimates a distribution over possible events and evaluates candidate teams using expected contextual value:

\[
EV(T)=\sum_e P(e|A_{history})V(T,A,e)
\]

The current implementation uses a history-informed prior that can be updated after each simulated event.

### 4.5 Team selection

The search is deliberately not brute-force over all 4-character combinations. Instead it uses beam search:

1. Start with an empty team.
2. Add one candidate character at a time.
3. Score partial teams.
4. Keep only the top `beam_width` partial teams.
5. Continue until the required team size is reached.

This reduces the combinatorial search while retaining multiple diverse candidate teams.

---

## 5. What the model does NOT claim

This repository is intentionally conservative.

It does **not** claim:
- that simulated scores are official Genshin scores;
- that popularity means combat strength;
- that the proxy synergy graph is the real in-game synergy graph;
- that the 103-character dataset is a complete current roster;
- that the simulator reproduces exact Genshin damage calculations;
- that the agent has been trained on real battle outcomes.

The correct interpretation is:

> **A transparent context-aware strategic planning prototype built from the supplied character dataset and the mechanics specified in the supplied challenge document.**

---

## 6. Suggested GitHub workflow

```bash
git init
git add .
git commit -m "Initial context-aware Genshin combat agent"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

Before submission, run:

```bash
pytest -q
python scripts/run_analysis.py
python scripts/run_experiment.py
```

Commit the generated `outputs/` if your instructor wants the results included in the repository.

---

## 7. Recommended presentation storyline

1. Problem: strongest team is not always the best team.
2. Data: 103 characters and 32 attributes/signals.
3. Key limitation: no battle outcome labels.
4. Solution: contextual team selection + uncertainty-aware planning.
5. Arena representation: weather + terrain + objective + hidden event.
6. Scoring: seven weighted dimensions.
7. Baselines: stat-only and popularity-only.
8. Experiments: repeated stochastic arenas.
9. Ablation: remove contextual components and observe degradation.
10. Limitations and future work: real combat logs, actual skill kits, learned policy/RL.



### Experiment size note

The default GitHub demo uses 50 episodes for the baseline comparison and 30 episodes per ablation condition. This keeps the repository runnable on an ordinary laptop while demonstrating the full pipeline. For a serious research study, increase the episode count substantially and report confidence intervals.
